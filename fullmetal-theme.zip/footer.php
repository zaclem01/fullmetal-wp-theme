</div>

<footer>
    <div class="footer_contact u-vertCenter">
        <p>Todd Hull</p>
        <p>Fullmetal Photography</p>
        <p>Address</p>
        <p>Louisville, KY Zip</p>
        <p>(555) 555-5555</p>
    </div>
    <div class="footer_social u-vertCenter">
        <i class="footer_social_icon fa fa-facebook"></i>
        <i class="footer_social_icon fa fa-twitter"></i>
        <i class="footer_social_icon fa fa-instagram"></i>
    </div>
    <div class="footer_copyright u-vertCenter">
        <p>Designed by Zac Clemans</p>
        <p>For Fullmetal Photography</p>
        <p><small>&copy;</small> 2016</p>
        <p>All rights reserved</p>
    </div>
</footer>

<?php wp_footer(); ?>

</body>
</html>